//
//  ViewController.swift
//  Project
//
//  Created by Prashanthi Rayala on 10/16/23.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioRecorderDelegate  {
    var audioRecorder: AVAudioRecorder?
    var audioURL: URL?
    var isRecording = false
    @IBOutlet weak var StartBtn: UIButton!
    var soundRec = AVAudioRecorder()
    override func viewDidLoad() {
        super.viewDidLoad()
        func configureAudioSession() {
            do {
                let session = AVAudioSession.sharedInstance()
                try session.setCategory(.record, mode: .default, options: [])
                try session.setActive(true)
            } catch {
                print("Error configuring audio session: \(error.localizedDescription)")
            }
        }
        // Do any additional setup after loading the view.
    }
    @IBAction func stopRec(_ sender: Any) {
        stopRecording()
    }
  
  
    @IBAction func BtnClicked(_ sender: Any) {
        recordAudio()

        let serverURL = URL(string: "https://82b2-104-251-241-109.ngrok-free.app")!
        

        let task = URLSession.shared.dataTask(with: serverURL) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                return
            }
            
            guard let data = data else {
                print("No data received")
                return
            }
            
            // Handle the data from the response
            do {
                let responseJSON = try JSONSerialization.jsonObject(with: data, options: [])
                print(data)
                print("Response JSON: \(responseJSON)")
            } catch {
                print("Error parsing JSON: \(error)")
            }
        }

        task.resume()

    }
    func recordAudio() {
        print("Recording started")
        if !isRecording {
            let audioFilename = getDocumentsDirectory().appendingPathComponent("recording.m4a")
            let settings: [String: Any] = [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 44100,
                AVNumberOfChannelsKey: 2,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
            ]

            do {
                audioRecorder = try AVAudioRecorder(url: audioFilename, settings: settings)
                audioRecorder?.delegate = self
                audioRecorder?.record()
                isRecording = true
                updateUI()
            } catch {
                print("Error starting recording: \(error.localizedDescription)")
            }
        }
    }
    func stopRecording() {
        if isRecording {
            audioRecorder?.stop()
            isRecording = false
            updateUI()
            
        }
    }

    func updateUI() {
       
    }
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if flag {
            audioURL = recorder.url
            print(audioURL!)
           

            do {
                let audioPlayer = try AVAudioPlayer(contentsOf: audioURL!)
                audioPlayer.prepareToPlay()
                audioPlayer.play()
            } catch {
                print("Error playing audio: \(error.localizedDescription)")
            }
            sendAudioToServer(audioURL: audioURL!)
            // Handle the recorded audio file here
        } else {
            print("Recording did not finish successfully")
        }
    }
    func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    func sendAudioToServer(audioURL: URL) {
        // Create a URL request to your server's endpoint
        let serverURL = URL(string: "https://82b2-104-251-241-109.ngrok-free.app")!
        var request = URLRequest(url: serverURL)
        request.httpMethod = "POST"

        // Create a data task to send the audio file
        URLSession.shared.uploadTask(with: request, fromFile: audioURL) { data, response, error in
            if let error = error {
                print("Error: \(error)")
            } else if let data = data {
                let responseString = String(data: data, encoding: .utf8)
                print("Response: \(responseString ?? "No response")")
                // Handle the server's response here
            }
        }.resume()
    }
}

